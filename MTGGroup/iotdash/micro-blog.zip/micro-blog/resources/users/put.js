if (!(me && me.id == this.id)) {
    cancel("This is not you", 401);
}